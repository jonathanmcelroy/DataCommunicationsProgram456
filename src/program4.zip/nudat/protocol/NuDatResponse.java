package nudat.protocol;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

/**
 * NuDatResponse
 *
 * October 16, 2014
 *
 * @author Jonathan McElroy
 * @version 0.2
 */
public class NuDatResponse extends NuDatMessage {

    ////////////////////
    // Members
    ////////////////////

    /**
     * The list of posts to respond with
     */
    private List<String> posts;

    /**
     * The index of the number of posts in the buffer
     */
    private final int POST_NUM_INDEX = 6;


    /**
     * The length of a buffer the requires requires in order to read the number of posts integer
     */
    private final int POST_NUM_REQUIRED_LENGTH = 8;

    /**
     * The index of the start of the data in the buffer
     */
    private final int DATA_START_INDEX = 8;

    /**
     * The length of a buffer the response requires in order to read the number of posts integer
     */
    private final int RESPONSE_REQUIRED_LENGTH = 10;
    
    /**
     * The largest value the query id can take
     */
    private final long LARGEST_UNSIGNED_INT = (long)(Math.pow(2, 32) - 1);

    ////////////////////
    // Constructors
    ////////////////////

    /**
     * Construct a NuDatResponse by giving it the buffer to parse.
     *
     * @param buffer
     *
     * @throws NuDatException
     */
    public NuDatResponse(byte[] buffer) throws NuDatException {
        // safety check
        if(buffer == null) {
            throw new NuDatException(ErrorCode.PACKETTOOSHORT);
        }

        // set the error code and queryID
        setErrorCodeFromBuffer(buffer);
        setQueryIdFromBuffer(buffer);

        // if the buffer is too short, stop and raise an exception
        if(buffer.length < RESPONSE_REQUIRED_LENGTH) {
            throw new NuDatException(ErrorCode.PACKETTOOSHORT);
        }

        // get the number of posts on the buffer
        int numPosts = readUnsignedShort(buffer, POST_NUM_INDEX);

        // initialize the lists of posts
        this.posts = new ArrayList<String>(numPosts);

        // initialize the index for each post
        int index = DATA_START_INDEX;

        // for each post
        for(int i = 0; i < numPosts; i++) {
            // if the buffer is not long enough to read 2 bytes, raise an exception
            if(index + 2 > buffer.length) {
                throw new NuDatException(ErrorCode.PACKETTOOSHORT);
            }

            // get the length of the post
            int postLength = readUnsignedShort(buffer, index);

            // if the buffer is not long enough to read the post, raise an exception
            if(index + 2 + postLength > buffer.length) {
                throw new NuDatException(ErrorCode.PACKETTOOSHORT);
            }

            // get post string
            String post = null;
            try {
                post = new String(buffer, index + 2, postLength, CHARENCODING);
            } catch (UnsupportedEncodingException e) {}

            // add the post to the list of posts
            this.posts.add(post);

            // move the index to the next post
            index += 2 + postLength;
        }

        // if there is still more data after the last post, then the buffer was too long
        if(buffer.length > index) {
            throw new NuDatException(ErrorCode.PACKETTOOLONG);
        }
    }

    /**
     * Construct a Resonse by giving it the values to use.
     *
     * @param errorCode
     * @param queryId
     * @param posts
     *
     * @throws IllegalArgumentException
     */
    public NuDatResponse(ErrorCode errorCode, long queryId, List<String> posts) throws IllegalArgumentException {
        // if the errorCode is not null, save it
        if(errorCode == null) {
            throw new IllegalArgumentException("ErrorCode must not be null");
        }
        this.errorCode = errorCode;

        // if the query fits in an unsigned, two-byte integer, save it
        if(queryId < 0 || queryId > LARGEST_UNSIGNED_INT) {
            throw new IllegalArgumentException("queryId must fit into an unsigned integer");
        }
        this.queryId = queryId;

        // if there is at least one post, save it
        if(posts == null || posts.size() <= 0) {
            throw new IllegalArgumentException("You must have at least 1 post");
        }
        this.posts = posts;
    }

    ////////////////////
    // Getters/Setters
    ////////////////////

    /**
     * Get the list of posts
     *
     * @return the list of posts
     */
    public List<String> getPosts() {
        return this.posts;
    }

    /**
     * Set the list of posts
     *
     * @param posts
     *
     * @throws IllegalArgumentException
     */
    public void setPosts(List<String> posts) throws IllegalArgumentException {
        // if there is not at least one post, throw an exception
        if(posts == null || posts.size() <= 0) {
            throw new IllegalArgumentException("You must have at least 1 post");
        }
        this.posts = posts;
    }


    /**
     * Set the error code
     *
     * @param errorCode
     */
    public void setErrorCode(ErrorCode errorCode) {
        this.errorCode = errorCode;
    }


    /**
     * Set the error code by its number
     *
     * @param errorCodeValue
     *
     * @throws IllegalArgumentException
     */
    public void setErrorCode(int errorCodeValue) throws IllegalArgumentException {
        this.errorCode = ErrorCode.getErrorCode(errorCodeValue);
    }

    ////////////////////
    // Methods
    ////////////////////

    /**
     * Encode the current attributes to a byte array
     *
     * @return the encode instance
     *
     * @throws NuDatException
     */
    @Override
    public byte[] encode() throws NuDatException {
        // this will build the string from the posts so that we can get the byte array
        StringBuilder sb = new StringBuilder();

        // for each post
        for(String post : this.posts) {
            // get the length of the post
            int length = post.length();
            
            // write the length as an unsigned, short
            sb.append((char)((length >> 8) & 0xFF));
            sb.append((char)((length) & 0xFF));
            
            // add the actual post after this
            sb.append(post);
        }

        // the encoded NuDatQuery to send to the server
        byte[] result = new byte[POST_NUM_REQUIRED_LENGTH + sb.length()];

        // set the version number and QR flag
        result[0] = 0b00100000;

        // write the error code and query id to the buffer
        writeErrorCodeToBuffer(result);
        writeQueryIdToBuffer(result);

        // write the requested number of posts to the buffer
        writeUnsignedShort(this.posts.size(), result, POST_NUM_INDEX);

        System.arraycopy(sb.toString().getBytes(), 0, result, DATA_START_INDEX, sb.length());

        return result;
    }

    /**
     * @return the string representation of the response
     */
    @Override
    public String toString() {
        return "NuDatResponse: queryId:" + queryId + ", errorCode:" + errorCode + ", posts:" + posts;
    }

}
